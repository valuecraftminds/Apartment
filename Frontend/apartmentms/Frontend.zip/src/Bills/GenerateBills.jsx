import { Plus } from 'lucide-react'
import React, { useState, useEffect } from 'react'
import GenerateSharedValueBill from './GenerateSharedValueBill';
import api from '../api/axios';

export default function GenerateBills() {
    const [showCreateModal, setShowCreateModal] = useState(false);
    const [generatedBills, setGeneratedBills] = useState([]);
    const [loading, setLoading] = useState(false);

    const loadGeneratedBills = async () => {
        try {
            setLoading(true);
            const response = await api.get('/generate-bills');
            if (response.data.success) {
                setGeneratedBills(response.data.data);
            }
        } catch (error) {
            console.error('Error loading generated bills:', error);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        loadGeneratedBills();
    }, []);

    const handleAddNew = () => {
        setShowCreateModal(true);
    }

    const handleCloseModal = () => {
        setShowCreateModal(false);
    };

    const handleGenerateBill = (newBills) => {
        if (newBills && newBills.length > 0) {
            setGeneratedBills(prev => [...newBills, ...prev]);
        }
        loadGeneratedBills(); // Reload to get all data
        setShowCreateModal(false);
    }

    return (
        <div className='flex-1 overflow-y-auto p-6'>
            <button 
                onClick={handleAddNew}
                className='flex items-center gap-2 mb-6 px-4 py-2 rounded-lg font-semibold shadow-md transition-all duration-300 text-white bg-purple-600 hover:bg-purple-700 hover:scale-105'>
                <Plus size={20} />
                <span>Generate Bills</span>
            </button>
            
            <div className='bg-white dark:bg-gray-800 rounded-2xl p-6 text-gray-700 dark:text-gray-300'>
                <h2 className="text-xl font-semibold mb-4 text-gray-800 dark:text-white">
                    Generated Bills
                </h2>
                
                {loading ? (
                    <div className="flex justify-center py-8">
                        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600"></div>
                    </div>
                ) : generatedBills.length === 0 ? (
                    <p className="text-gray-500 dark:text-gray-400 text-center py-8">
                        No bills generated yet. Click "Generate Bills" to create new bills.
                    </p>
                ) : (
                    <div className="space-y-4">
                        {generatedBills.map((bill) => (
                            <div key={bill.id} className="border border-gray-200 dark:border-gray-700 rounded-lg p-4 hover:shadow-md transition-shadow">
                                <div className="flex justify-between items-start">
                                    <div>
                                        <h3 className="font-semibold text-lg text-gray-800 dark:text-white">
                                            {bill.bill_name || 'Bill'}
                                        </h3>
                                        <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                                            Type: <span className="font-medium">{bill.billtype || 'N/A'}</span> | 
                                            Period: <span className="font-medium">{bill.month} {bill.year}</span>
                                        </p>
                                        <p className="text-xs text-gray-500 mt-1">
                                            Generated on: {new Date(bill.created_at).toLocaleDateString()}
                                        </p>
                                    </div>
                                    <div className="text-right">
                                        <span className="inline-block px-2 py-1 text-xs font-semibold rounded-full bg-green-100 text-green-800 dark:bg-green-800 dark:text-green-100">
                                            Generated
                                        </span>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                )}
            </div>

            {showCreateModal && (
                <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50">
                    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl p-6 w-full max-w-2xl relative">
                        <button
                            onClick={handleCloseModal}
                            className="absolute top-4 right-4 text-gray-500 hover:text-gray-800 dark:hover:text-white text-xl"
                        >
                            ✖
                        </button>
                        <h2 className="text-xl font-semibold mb-4 text-gray-800 dark:text-white">
                            Generate New Bills
                        </h2>
                        <GenerateSharedValueBill
                            onClose={handleCloseModal}
                            onCreated={handleGenerateBill}
                        />
                    </div>
                </div>
            )}
        </div>
    )
}