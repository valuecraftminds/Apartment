import React, { useState, useEffect } from 'react'
import api from '../api/axios';


export default function GenerateSharedValueBill({ onClose, onCreated }) {
    const [loadingBills, setLoadingBills] = useState(false);
    const [generating, setGenerating] = useState(false);
    const [error, setError] = useState(null);
    const [bills, setBills] = useState([]);
    const [selectedBillType, setSelectedBillType] = useState('');
    const [selectedBills, setSelectedBills] = useState([]);
    const [year, setYear] = useState(new Date().getFullYear());
    const [month, setMonth] = useState(new Date().toLocaleString('default', { month: 'long' }));

    const loadBills = async () => {
        try {
            setLoadingBills(true);
            setError(null);
            const result = await api.get('/bills');
            if (result.data.success && Array.isArray(result.data.data)) {
                setBills(result.data.data);
            } else {
                setBills([]);
            }
        } catch (err) {
            console.error('Error loading bills:', err);
            setError('Failed to load bills. Please try again.');
        } finally {
            setLoadingBills(false);
        }
    };

    useEffect(() => {
        loadBills();
    }, []);

    // Filter bills - Only show non-measurable bills
    const otherBills = bills.filter(bill => bill.billtype !== 'Measurable');
    
    // Get unique bill types
    const billTypes = [...new Set(otherBills.map(bill => bill.billtype))];

    // Filter bills by selected type
    const filteredBills = selectedBillType 
        ? otherBills.filter(bill => bill.billtype === selectedBillType)
        : [];

    const handleBillTypeChange = (type) => {
        setSelectedBillType(type);
        setSelectedBills([]);
    };

    const handleBillSelection = (billId) => {
        setSelectedBills(prev => {
            if (prev.includes(billId)) {
                return prev.filter(id => id !== billId);
            } else {
                return [...prev, billId];
            }
        });
    };

    const handleSelectAll = () => {
        if (selectedBills.length === filteredBills.length) {
            setSelectedBills([]);
        } else {
            setSelectedBills(filteredBills.map(bill => bill.id));
        }
    };

    const handleGenerateBills = async () => {
        if (selectedBills.length === 0) {
            setError('Please select at least one bill to generate.');
            return;
        }

        try {
            setGenerating(true);
            setError(null);

            const billsToGenerate = selectedBills.map(billId => ({
                bill_id: billId,
                year: year,
                month: month
            }));

            const response = await api.post('/generate-bills/bulk', { bills: billsToGenerate });
            
            if (response.data.success) {
                onCreated(response.data.data);
            } else {
                setError(response.data.message || 'Failed to generate bills');
            }

        } catch (err) {
            console.error('Error generating bills:', err);
            setError(err.response?.data?.message || 'Failed to generate bills. Please try again.');
        } finally {
            setGenerating(false);
        }
    };

    return (
        <div className="space-y-4">
            {error && (
                <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded text-sm">
                    {error}
                </div>
            )}

            {/* Year and Month Selection */}
            <div className="grid grid-cols-2 gap-4">
                <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        Year
                    </label>
                    <select
                        value={year}
                        onChange={(e) => setYear(parseInt(e.target.value))}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-purple-500 dark:bg-gray-700 dark:text-white"
                    >
                        {[2023, 2024, 2025].map(y => (
                            <option key={y} value={y}>{y}</option>
                        ))}
                    </select>
                </div>
                <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        Month
                    </label>
                    <select
                        value={month}
                        onChange={(e) => setMonth(e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-purple-500 dark:bg-gray-700 dark:text-white"
                    >
                        {['January', 'February', 'March', 'April', 'May', 'June', 
                          'July', 'August', 'September', 'October', 'November', 'December'].map(m => (
                            <option key={m} value={m}>{m}</option>
                        ))}
                    </select>
                </div>
            </div>

            {/* Bill Type Selection */}
            <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Bill Type
                </label>
                <select
                    value={selectedBillType}
                    onChange={(e) => handleBillTypeChange(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-purple-500 dark:bg-gray-700 dark:text-white"
                    disabled={loadingBills}
                >
                    <option value="">Select Bill Type</option>
                    {billTypes.map(type => (
                        <option key={type} value={type}>{type}</option>
                    ))}
                </select>
            </div>

            {/* Bills List */}
            {selectedBillType && (
                <div>
                    <div className="flex justify-between items-center mb-2">
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                            Select Bills
                        </label>
                        <span className="text-sm text-gray-500">
                            {selectedBills.length} selected
                        </span>
                    </div>
                    
                    {filteredBills.length === 0 ? (
                        <p className="text-gray-500 dark:text-gray-400 text-center py-4 text-sm">
                            No bills found for selected type.
                        </p>
                    ) : (
                        <div className="border border-gray-200 dark:border-gray-600 rounded-md max-h-60 overflow-y-auto">
                            <div className="p-3 border-b border-gray-200 dark:border-gray-600 bg-gray-50 dark:bg-gray-700">
                                <label className="flex items-center space-x-3 cursor-pointer">
                                    <input
                                        type="checkbox"
                                        checked={selectedBills.length === filteredBills.length && filteredBills.length > 0}
                                        onChange={handleSelectAll}
                                        className="rounded border-gray-300 text-purple-600 focus:ring-purple-500"
                                    />
                                    <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Select All</span>
                                </label>
                            </div>
                            
                            {filteredBills.map(bill => (
                                <div key={bill.id} className="p-3 border-b border-gray-100 dark:border-gray-600 last:border-b-0 hover:bg-gray-50 dark:hover:bg-gray-700">
                                    <label className="flex items-center space-x-3 cursor-pointer">
                                        <input
                                            type="checkbox"
                                            checked={selectedBills.includes(bill.id)}
                                            onChange={() => handleBillSelection(bill.id)}
                                            className="rounded border-gray-300 text-purple-600 focus:ring-purple-500"
                                        />
                                        <div className="flex-1">
                                            <span className="text-sm font-medium text-gray-700 dark:text-gray-300">{bill.bill_name}</span>
                                        </div>
                                    </label>
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            )}

            {/* Action Buttons */}
            <div className="flex justify-end space-x-3 pt-4">
                <button
                    onClick={onClose}
                    className="px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-600 rounded-md hover:bg-gray-200 dark:hover:bg-gray-500 transition-colors"
                    disabled={generating}
                >
                    Cancel
                </button>
                <button
                    onClick={handleGenerateBills}
                    disabled={selectedBills.length === 0 || generating}
                    className="px-4 py-2 text-sm font-medium text-white bg-purple-600 rounded-md hover:bg-purple-700 disabled:bg-purple-400 disabled:cursor-not-allowed transition-colors flex items-center space-x-2"
                >
                    {generating ? (
                        <>
                            <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                            <span>Generating...</span>
                        </>
                    ) : (
                        <span>Generate Bills ({selectedBills.length})</span>
                    )}
                </button>
            </div>
        </div>
    )
}